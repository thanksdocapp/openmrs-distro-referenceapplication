export const pharmacymeta = {
  name: 'pharmacy',
  title: 'Pharmacy',
  externalUrl: 'https://app.quincy.health/login',
};

export const scansmeta = {
  name: 'scans',
  title: 'Scans',
  externalUrl: 'https://www.vista-health.co.uk/',
};

export const labTestsMeta = {
  name: 'lab-tests',
  title: 'Lab Tests',
  externalUrl: 'https://nwpblood.co.uk/sec_Login/',
};

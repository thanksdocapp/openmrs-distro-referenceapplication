import React from 'react';
import { interpolateUrl, useConfig } from '@openmrs/esm-framework';
import { type TFunction } from 'react-i18next';
import { type ConfigSchema } from './config-schema';
import styles from './login/login.scss';
import thanksDoctorLogo from './assets/thanksDoc.svg';

const Logo: React.FC<{ t: TFunction }> = ({ t }) => {
  const { logo } = useConfig<ConfigSchema>();
  return logo.src ? (
    <img
      alt={logo.alt ? t(logo.alt) : t('openmrsLogo', 'ThanksDoctor logo')}
      className={styles.logoImg}
      src={interpolateUrl(logo.src)}
    />
  ) : (
    // <svg role="img" className={styles.logo}>
    //   <title>{t('openmrsLogo', 'ThanksDoctor logo')}</title>
    //   <use href="#omrs-logo-full-color"></use>
    // </svg> 
     <img
      alt='ThanksDoctor logo'
      className={styles.logoImg}
      title='ThanksDoctor Logo'
      src={thanksDoctorLogo}
    />    
  );
};

export default Logo;

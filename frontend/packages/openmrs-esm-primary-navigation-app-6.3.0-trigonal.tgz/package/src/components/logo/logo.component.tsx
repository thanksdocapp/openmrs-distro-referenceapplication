import React from 'react';
import { interpolateUrl, useConfig } from '@openmrs/esm-framework';
import { type ConfigSchema } from '../../config-schema';
import styles from './logo.scss';
import thanksDoctorLogo from '../assets/thanksDoc.svg';

const Logo: React.FC = () => {
  const { logo } = useConfig<ConfigSchema>();

  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement>) => {
    console.error('Failed to load logo image:', e);
  };

  return (
    <>
      {logo?.src ? (
        <img alt={logo.alt} className={styles.logo} onError={handleImageError} src={interpolateUrl(logo.src)} />
      ) : logo?.name ? (
        logo.name
      ) : (
        // <svg aria-label="OpenMRS Logo" role="img" width={110} height={40}>
        //   <use href="#omrs-logo-white" />
        // </svg>
        <img
            alt='ThanksDoctor logo'
            width={110} height={40}
            className={styles.logoImg}
            title='ThanksDoctor Logo'
            src={thanksDoctorLogo}
          />    
      )}
    </>
  );
};

export default Logo;
